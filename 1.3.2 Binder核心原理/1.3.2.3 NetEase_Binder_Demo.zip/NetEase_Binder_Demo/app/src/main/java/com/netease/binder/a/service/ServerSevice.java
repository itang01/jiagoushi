package com.netease.binder.a.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.netease.binder.a.bean.Person;
import com.netease.binder.a.server.BinderObj;

import java.util.ArrayList;
import java.util.List;

/**
 * onBind方法返回mStub对象，也就是Server中的Binder实体对象
 */
public class ServerSevice extends Service {

    private static final String TAG = "ServerSevice";
    private List<Person> mPeople = new ArrayList<>();

    @Override
    public void onCreate() {
        mPeople.add(new Person());
        super.onCreate();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mStub;
    }

    private BinderObj mStub = new BinderObj() {

        @Override
        public void addPerson(Person mPerson) {
            if (mPerson == null) {
                mPerson = new Person();
                Log.e(TAG, "null obj");
            }
            mPeople.add(mPerson);
            Log.e(TAG, mPeople.size() + "");
        }

        @Override
        public List<Person> getPersonList() {
            return mPeople;
        }
    };
}
