package com.netease.binder.a;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.netease.binder.a.bean.Person;
import com.netease.binder.a.server.BinderObj;
import com.netease.binder.a.service.ServerSevice;

import java.util.List;

/**
 * bindService传入一个ServiceConnection对象，在与服务端建立连接时，
 * 通过我们定义好的BinderObj的asInterface方法返回一个代理对象，再调用方法进行交互
 */
public class MainActivity extends AppCompatActivity {

    private boolean isConnect = false;
    private static final String TAG = "MainActivity";
    private PersonManger personManger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start();
        findViewById(R.id.textView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (personManger == null) {
                    Log.e(TAG, "connect error");
                    return;
                }
                personManger.addPerson(new Person());
                Log.e(TAG, personManger.getPersonList().size() + "");
            }
        });
    }

    private void start() {
        Intent intent = new Intent(this, ServerSevice.class);
        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.e(TAG, "connect success");
            isConnect = true;
            personManger = BinderObj.asInterface(service);
            List<Person> personList = personManger.getPersonList();
            Log.e(TAG, personList.size() + "");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(TAG, "connect failed");
            isConnect = false;
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isConnect) unbindService(mServiceConnection);
    }
}
