package com.netease.binder.a.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.netease.binder.ILoginInterface;

public class MyService extends Service {

    @Override
    public IBinder onBind(Intent intent) {

        return new ILoginInterface.Stub() {
            @Override
            public void login() throws RemoteException {
            }

            @Override
            public void loginCallback(boolean loginStatus, String loginUser) throws RemoteException {
                Log.e("netease >>> ", "loginStatus: " + loginStatus + " / loginUser: " + loginUser);
            }
        };
    }
}
