package com.netease.binder.a;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.netease.binder.ILoginInterface;

public class MainActivity extends Activity {

    private boolean isStartRemote; // 是否开启跨进程通信
    private ILoginInterface iLogin; // AIDL定义接口

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE); // 隐藏标题
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); // 设置全屏

        setContentView(R.layout.activity_main);

        initBindService();
    }

    // 点击事件
    public void startQQLoginAction(View view) {
        if (iLogin != null) {
            try {
                // 调用Server方法
                iLogin.login();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "请安装QQ应用...", Toast.LENGTH_SHORT).show();
        }
    }

    public void initBindService() {
        Intent intent = new Intent();
        // 设置Server应用Action
        intent.setAction("BinderB_Action");
        // 设置Server应用包名（5.1+要求）
        intent.setPackage("com.netease.binder.b");
        // 开始绑定服务
        bindService(intent, conn, BIND_AUTO_CREATE);
        // 标识跨进程绑定
        isStartRemote = true;
    }

    // 服务连接
    private ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            iLogin = ILoginInterface.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (isStartRemote) {
            // 解绑服务，一定要记得解绑服务，否则可能会报异常(服务连接资源异常)
            unbindService(conn);
        }
    }
}
